WertySMP God Weapons + LONGINUS (исправлено)

Обычное незеритовое копьё больше НЕ переопределяется ресурс-паком.
Модель LONGINUS вынесена в отдельный item model: wertysmp:longinus.
Меч Бога и Булава Бога сохранены.

Выдача отдельного копья LONGINUS на Minecraft 1.21.11:
/minecraft:give @p minecraft:netherite_spear[minecraft:item_model="wertysmp:longinus",minecraft:custom_name={"text":"⚔ LONGINUS ⚔","color":"dark_red","bold":true}] 1

Если сервер/команда не принимает custom_name, выдай без него:
/minecraft:give @p minecraft:netherite_spear[minecraft:item_model="wertysmp:longinus"] 1

После замены ресурспака нажми F3+T.
