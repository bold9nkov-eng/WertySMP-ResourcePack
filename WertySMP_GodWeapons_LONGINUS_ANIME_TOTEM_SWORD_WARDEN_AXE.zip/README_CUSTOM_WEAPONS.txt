WertySMP custom models for Minecraft Java 1.21.11

Shadow Sword (use while holding a netherite sword):
/item replace entity @p weapon.mainhand with minecraft:netherite_sword[minecraft:item_model="wertysmp:shadow_sword"]

Warden Axe (use while holding a netherite axe):
/item replace entity @p weapon.mainhand with minecraft:netherite_axe[minecraft:item_model="wertysmp:warden_axe"]

Give commands:
/give @p minecraft:netherite_sword[minecraft:item_model="wertysmp:shadow_sword"] 1
/give @p minecraft:netherite_axe[minecraft:item_model="wertysmp:warden_axe"] 1

The resource pack must be enabled on the client/server. These commands change the item's model; they do not add custom attack damage or abilities.
