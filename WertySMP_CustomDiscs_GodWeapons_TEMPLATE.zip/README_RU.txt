WertySMP — кастомные пластинки + Меч Бога + Булава Бога

ВАЖНО:
В архиве сохранены модели и текстуры Меча Бога и Булавы Бога.
Система звуков уже настроена, но аудиофайлы музыки НЕ включены, потому что они не были загружены вместе с исходным архивом.

Чтобы музыка реально играла, добавь свои .ogg-файлы в:
assets/minecraft/sounds/wertysmp/discs/

Имена файлов:
montagem_guerreiro.ogg
funk_monocle.ogg
montagem_uranium.ogg
montagem_unknown.ogg
montagem_domer.ogg
montagem_fearless.ogg
brega_do_love.ogg
montagem_alquimia.ogg
al_nacer.ogg
fortuna_812_por_ezy.ogg
verity_hardtekk.ogg
dinastiya_villian.ogg
11eight_fruktovy.ogg

Соответствие:
Creator -> MONTAGEM GUERREIRO (Slowed)
Mellohi -> FUNK MONOCLE (Slowed)
Chirp -> MONTAGEM URANIUM (Slowed)
13 -> MONTAGEM UNKNOWN
Cat -> MONTAGEM DOMER (Ultra Slowed)
Otherside -> MONTAGEM FEARLESS (Ultra Slowed)
Pigstep -> BREGA DO LOVE (Slowed)
Precipice -> MONTAGEM ALQUIMIA
Wait -> AL NACER - Sayfalse, Nulteex
Tears -> FORTUNA 812, ELOX1M - ПОРЕЗЫ НА РУКАХ
Lava Chicken -> VERITY HARDTEKK
5 -> ДИНАСТИЯ-VILLIAN
Strad -> 11Eight-Фруктовый

Minecraft требует OGG Vorbis для обычных ресурс-пак звуков.
