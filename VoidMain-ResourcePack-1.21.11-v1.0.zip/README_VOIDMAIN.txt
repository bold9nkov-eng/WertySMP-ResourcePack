VoidMain Resource Pack — 1.21.11 (alpha)

Сохранено из исходного архива:
- Меч Бога и Булава Бога
- Теневой меч и топор Warden
- Void-броня и существующие модели
- Существующие ресурсные файлы

Добавлено:
- pack.png с логотипом VoidMain
- Текстура магического свитка
- Item definition: voidmain:enchant_scroll
- Модель: voidmain:item/enchant_scroll

Команда для проверки свитка:
 /give @p minecraft:enchanted_book[minecraft:item_model="voidmain:enchant_scroll"] 1

Важно:
- Это промежуточная сборка ресурс-пака. Плагин пока не обновлён.
- Для использования свитка плагин должен выдавать enchanted_book с компонентом minecraft:item_model="voidmain:enchant_scroll".
- Новые звуковые OGG пока не встроены: они будут добавлены после скачивания и проверки файлов.
- Частицы Minecraft создаются серверным плагином, а не одним только ресурс-паком.
- Старое пространство имён wertysmp оставлено для совместимости существующих моделей.
