# VoidMain Resource Pack — Minecraft Java 1.21.11

## Состав
- Сохранены существующие кастомные модели оружия, брони и предметов из alpha-архива.
- Добавлен магический свиток: `voidmain:item/enchant_scroll` (item model id `voidmain:enchant_scroll`).
- `pack.png` оформлен логотипом VoidMain. `server-icon.png` — отдельный файл для корневой папки сервера.
- Добавлен набор пиксельных GUI-глифов: `voidmain:icons`.
- Добавлены звуковые события `voidmain:scroll_open`, `voidmain:enchant_apply`, `voidmain:reward_common`, `voidmain:reward_rare`, `voidmain:reward_epic`, `voidmain:reward_legendary`, а также `voidmain:enchant/<id>`.

## Свиток в игре
Для предмета используйте современный item model component: `minecraft:custom_data`/PDC для идентификации и `minecraft:item_model` со значением `voidmain:enchant_scroll`. Для Minecraft 1.21.11 модель лежит в `assets/voidmain/items/enchant_scroll.json`.

## GUI-глифы
В MiniMessage можно использовать шрифт `voidmain:icons`, например: `<font:voidmain:icons>\uE010</font>` для меча, `\uE011` для топора, `\uE012` для булавы, `\uE013` для кирки, `\uE015` для щита, `\uE000` для свитка. Редкости: `\uE020` обычная, `\uE021` редкая, `\uE022` эпическая, `\uE023` легендарная.

## Звуковые события
Плагин может вызывать строки `voidmain:scroll_open`, `voidmain:enchant_apply`, `voidmain:reward_legendary`, `voidmain:enchant/frost`, `voidmain:enchant/venom`, `voidmain:enchant/thunder` и т. д. События сейчас используют подходящие встроенные звуки Minecraft как рабочие заглушки, чтобы пакет работал без отсутствующих OGG-файлов. После выбора и загрузки конкретных внешних OGG можно заменить `type: event` на `type: file` в `assets/voidmain/sounds.json`, не меняя ID, вызываемые плагином.

## Установка
1. ZIP можно выдать игрокам как серверный ресурс-пак.
2. `server-icon.png` скопировать отдельно в корневую папку Paper-сервера (рядом с `server.properties`).
3. В `server.properties` задать `resource-pack=<прямая HTTPS-ссылка на ZIP>` и `require-resource-pack=true` при необходимости.

## Внешние CC0-звуки для следующего этапа
- SpritePilot Magic SFX (16 эффектов, OGG/WAV/MP3, CC0): https://spritepilot.com/free-game-assets/sound-effects/magic
- OpenGameArt Magic Spell SFX (CC0, OGG): https://opengameart.org/content/magic-spell-sfx
- SFXMint Fantasy RPG (CC0, MP3; WAV pack): https://sfxmint.com/sets/fantasy-rpg
Лицензии проверять по странице автора при скачивании.

## Ограничение текущего этапа
Текстуры и звуковые события добавлены в ресурс-пак. Реальное проигрывание кастомных звуков, вспышки частиц и выдачу свитков по событиям должен запускать серверный плагин. Обычные inventory GUI-фоны нельзя индивидуально заменить ресурс-паком; здесь добавлены пиксельные glyph-иконки для отрисовки в названиях/лоре меню.
