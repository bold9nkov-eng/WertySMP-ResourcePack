WertySMP_GodWeapons_16x16_FINAL

Этот ресурс-пак содержит:
- Меч Бога
- Булаву Бога
- Кастомную музыку для пластинок

ВАЖНО:
Пластинка Otherside сейчас использует MONTAGEM FEARLESS (Ultra Slowed), как было указано.
Трек LIGHTPREY - ЦЕЛОВАТЬСЯ отсутствовал в загруженном архиве музыки, поэтому он НЕ добавлен вместо второй записи otherside.

Для сервера:
Ресурс-пак должен быть установлен у клиента или выдан сервером как server resource pack.
После смены ресурспака нажмите F3+T для перезагрузки ресурсов.


Добавлено: Копьё Бездны (2D-текстура).
Minecraft Java 1.21.11: /give @p minecraft:trident[minecraft:item_model="minecraft:god_spear",minecraft:custom_name={"text":"Копьё Бездны","color":"dark_purple","italic":false}] 1
