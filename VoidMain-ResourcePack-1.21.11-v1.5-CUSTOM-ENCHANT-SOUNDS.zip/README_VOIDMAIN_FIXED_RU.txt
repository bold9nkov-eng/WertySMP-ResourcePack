# VoidMain Resource Pack 1.21.11 — FIXED v1.2 — VoidEnchantments 3.0.0

## Что сохранено
- Старые модели и текстуры: Longinus, Shadow Sword, Warden Axe, Anime Totem, Void Armor (все 4 части), God Sword и God Mace.
- Все модели и текстуры из двух исходных архивов объединены без удаления старых путей.
- Магический свиток: `voidmain:enchant_scroll`.
- GUI-глифы: `voidmain:icons`.
- Настоящие оригинальные OGG-звуки и локальные звуковые события `voidmain:*` (не заглушки из ванильных звуков).
- Переводы субтитров ru_ru/en_us.

## Item model IDs для Paper 1.21.11
Используются современные компоненты `minecraft:item_model`, например:
```mcfunction
/give @p minecraft:netherite_sword[minecraft:item_model="wertysmp:shadow_sword"] 1
/give @p minecraft:netherite_axe[minecraft:item_model="wertysmp:warden_axe"] 1
/give @p minecraft:netherite_sword[minecraft:item_model="wertysmp:longinus"] 1
/give @p minecraft:netherite_helmet[minecraft:item_model="wertysmp:void_helmet"] 1
/give @p minecraft:netherite_chestplate[minecraft:item_model="wertysmp:void_chestplate"] 1
/give @p minecraft:netherite_leggings[minecraft:item_model="wertysmp:void_leggings"] 1
/give @p minecraft:netherite_boots[minecraft:item_model="wertysmp:void_boots"] 1
/give @p minecraft:paper[minecraft:item_model="voidmain:enchant_scroll"] 1
```
Для брони, отображаемой на игроке, сам плагин должен также задавать `minecraft:equippable` с `asset_id=wertysmp:void_armor` (и подходящий слот). Одного item_model недостаточно для текстуры надетой брони.

## Звуки
Плагин может вызывать `player.playSound(location, "voidmain:scroll_open", SoundCategory.PLAYERS, 1f, 1f)` и аналогичные ID из `assets/voidmain/sounds.json`. Доступны `voidmain:scroll_open`, `voidmain:enchant_apply`, `voidmain:reward_common/rare/epic/legendary`, а также `voidmain:enchant/<id>` и отдельные семейства эффектов, включая `voidmain:enchant/berserk`.

## Частицы и вспышки
Частицы не могут запускаться одним ресурспаком. Их должен вызывать плагин в момент успешного срабатывания способности. Рекомендуемые эффекты: `SPELL_WITCH`/`PORTAL` для магии, `SNOWFLAKE` для Frost, `CRIT` для ударов, `SOUL`/`REVERSE_PORTAL` для Black Hole, `ELECTRIC_SPARK` для Thunder, `TOTEM_OF_UNDYING` для легендарного открытия. Не запускать эффекты на каждый обычный удар — только при подтверждённом proc.

## Установка
1. Установить этот ZIP как server resource pack.
2. После замены нажать `F3+T` или удалить старый кэш ресурспака и зайти заново.
3. Если конкретный предмет всё ещё показывает чёрно-фиолетовый куб, проверьте, что плагин выдаёт именно указанный `item_model` ID: имя предмета/PDC само по себе модель не выбирает.
4. Для сервера отдельно скопировать `server-icon.png` в корень сервера.
